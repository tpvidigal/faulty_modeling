var annotated_dup =
[
    [ "BufferFault", "classBufferFault.html", "classBufferFault" ],
    [ "FaultDatabase", "classFaultDatabase.html", "classFaultDatabase" ],
    [ "FaultyBuffer", "classFaultyBuffer.html", "classFaultyBuffer" ],
    [ "FIMethod", "structFIMethod.html", "structFIMethod" ],
    [ "Matrix", "classMatrix.html", "classMatrix" ],
    [ "PIDSimplex", "classPIDSimplex.html", "classPIDSimplex" ],
    [ "PIDTMR", "classPIDTMR.html", "classPIDTMR" ],
    [ "PIDTMRSimplex", "classPIDTMRSimplex.html", "classPIDTMRSimplex" ]
];