var Voter_8hpp =
[
    [ "SC_MODULE", "Voter_8hpp.html#a40731f09b345dbf419835ce6c95d9e27", null ]
];