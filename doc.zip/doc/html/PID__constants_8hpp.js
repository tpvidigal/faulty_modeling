var PID__constants_8hpp =
[
    [ "FIMethod", "structFIMethod.html", "structFIMethod" ],
    [ "CLK_DUTY", "PID__constants_8hpp.html#aa63a6c64621c34a7de6eb1fe8a71855b", null ],
    [ "CLK_PERIOD", "PID__constants_8hpp.html#a28a170e5b519a27088663c3bf3f5b826", null ],
    [ "ERROR_ACTUATOR", "PID__constants_8hpp.html#ae9261c040cbe95fbe55f24364557db41", null ],
    [ "ERROR_PID", "PID__constants_8hpp.html#a02196e5b6c5efa67986daed4fb1c6968", null ],
    [ "ERROR_PLANT", "PID__constants_8hpp.html#ad19f47b0e43a6bd62cc17a0c692d109c", null ],
    [ "ERROR_SYS", "PID__constants_8hpp.html#ad86cf7e0e18ca235baef880c0be50e03", null ],
    [ "EXP_DIST_LAMBDA", "PID__constants_8hpp.html#a678e2ccd0256f25090d5c314ca341ef5", null ],
    [ "KD_DEFAULT", "PID__constants_8hpp.html#ae9d77cc5fa5e145139850b41def5f73a", null ],
    [ "KI_DEFAULT", "PID__constants_8hpp.html#ac5bc47d253125298dc57804a203ca8cd", null ],
    [ "KP_DEFAULT", "PID__constants_8hpp.html#af8662f06189af76844a4b2bb2e83d60c", null ],
    [ "STEP_RISE_TIME", "PID__constants_8hpp.html#a37a99af76f924db3c4748c7d3d81b5b5", null ],
    [ "FI_METHOD", "PID__constants_8hpp.html#aeab610ab6bd6d569f48ecd25884b1389", null ],
    [ "float_pid", "PID__constants_8hpp.html#af488982e337ecc36ca224088abc68b86", null ],
    [ "FAULT_TYPE", "PID__constants_8hpp.html#adc06fe6ba4817b5bd84bae5db6cb63a9", [
      [ "STUCK_AT_0", "PID__constants_8hpp.html#adc06fe6ba4817b5bd84bae5db6cb63a9a60fb39f008dfbae402242c725773ae60", null ]
    ] ],
    [ "bin2double", "PID__constants_8hpp.html#a16967c7fc31e05c0d08eb7db7b8552ff", null ]
];