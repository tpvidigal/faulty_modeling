var classBufferFault =
[
    [ "BufferFault", "classBufferFault.html#a2afe2e37d61283bd574b3c712241051f", null ],
    [ "getFaultMethod", "classBufferFault.html#a122942e19d73f967659f01e0028dbae0", null ],
    [ "getModule", "classBufferFault.html#a79445ff9cabaea9e04df073f08f70c69", null ],
    [ "getTimeToInject", "classBufferFault.html#abca66d0c795ec7290bff21dceb4c87c7", null ],
    [ "isPending", "classBufferFault.html#a4ca8ce9be78af21cf5bff845050c10be", null ],
    [ "fault_method", "classBufferFault.html#af03062fb2e99a73e818b6ee0dfa74580", null ],
    [ "module", "classBufferFault.html#a39e4633cd00381a77553e738aabd2842", null ],
    [ "time_to_inject", "classBufferFault.html#a69cf7f186b2e450b94465af25f536cf3", null ]
];