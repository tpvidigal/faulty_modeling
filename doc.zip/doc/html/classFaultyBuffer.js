var classFaultyBuffer =
[
    [ "FaultyBuffer", "classFaultyBuffer.html#a0221725307b5d7dacd299ef8489b586b", null ],
    [ "faultStuckAtZero", "classFaultyBuffer.html#a7518002847accfae695f49ec96d44204", null ],
    [ "injectFault", "classFaultyBuffer.html#a0bd48e92f12514c86d815800b675cc99", null ],
    [ "setFault", "classFaultyBuffer.html#a6db446ca20f69289bfff4714163395a8", null ],
    [ "write", "classFaultyBuffer.html#a7253500f7d376aed620d97fe4858adf9", null ],
    [ "distribution", "classFaultyBuffer.html#a66edbfc533eb1eacf6639ffab0bc844a", null ],
    [ "fault", "classFaultyBuffer.html#a361f5fb5e66f18c8316c61f8c29d1ce9", null ],
    [ "generator", "classFaultyBuffer.html#a7acbd912975a778abdde3437cea1047f", null ]
];