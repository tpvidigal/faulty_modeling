var classFaultDatabase =
[
    [ "FaultDatabase", "classFaultDatabase.html#a18689f55dde6720bcc86d30c311d55e4", null ],
    [ "FaultDatabase", "classFaultDatabase.html#a4fa6506cc7b8201b49d6adf92bdd4d68", null ],
    [ "getBufferFaults", "classFaultDatabase.html#a85743cc914ff471727e24e15752daaaf", null ],
    [ "getInstance", "classFaultDatabase.html#a357ec231a6f24f687fbe6ffbc82be1b5", null ],
    [ "operator=", "classFaultDatabase.html#a0f8f7d67657c8f74b0ddf823d987fedb", null ],
    [ "registerPossibleFault", "classFaultDatabase.html#a94470dbf73e574046a3741a5155d57c1", null ],
    [ "faults", "classFaultDatabase.html#a072143cce5f47ec2a83640da04b093b5", null ],
    [ "singleton", "classFaultDatabase.html#a90263a18d98e78eabd700ad5b44e6b4e", null ]
];