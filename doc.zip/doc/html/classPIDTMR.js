var classPIDTMR =
[
    [ "doPID", "classPIDTMR.html#aaf1c893ed063ade60f0ce705bb2a1378", null ],
    [ "SC_CTOR", "classPIDTMR.html#a44b15b08e2d8fe5b5599a5cb64fa6c93", null ],
    [ "sendGainsToVoter", "classPIDTMR.html#ace8fab57f0d64030c4f74ab18a3b84b5", null ],
    [ "sendOutputGain", "classPIDTMR.html#afe57a0857decf8cb257932224f3ccb72", null ],
    [ "setCoeffs", "classPIDTMR.html#af5f618ff946fa60be889807d10ce969a", null ],
    [ "pid_0", "classPIDTMR.html#a1a3948870c9dd71a23e589728b137b3f", null ],
    [ "pid_1", "classPIDTMR.html#ac11825db0a2eb9493ae4f80440692b1a", null ],
    [ "pid_2", "classPIDTMR.html#ad43fc6def6cbd38fbc744e016a05c5da", null ],
    [ "s_gain_0", "classPIDTMR.html#ad2dc7ce5141257781f2555af075cfb56", null ],
    [ "s_gain_1", "classPIDTMR.html#af912781489dc79135d235142805ef19f", null ],
    [ "s_gain_2", "classPIDTMR.html#a8c84211c5875bea1c1c1181c4b861f26", null ],
    [ "voter", "classPIDTMR.html#a273e105018148b68faa317ccce550e85", null ]
];