var classMatrix =
[
    [ "Matrix", "classMatrix.html#a2b1fedfb1b076d4ae504d2c61019871f", null ],
    [ "Matrix", "classMatrix.html#a4faae27840338e335187b7c361557d82", null ],
    [ "Matrix", "classMatrix.html#abf27c420c8d2d1709e9353f1f372672b", null ],
    [ "~Matrix", "classMatrix.html#a9b1c3627f573d78a2f08623fdfef990f", null ],
    [ "allocate", "classMatrix.html#a2888b190fa46fb901ef254de583ad2ea", null ],
    [ "deallocate", "classMatrix.html#a06726c819199acdd66a78790311fb43d", null ],
    [ "fill", "classMatrix.html#ae5f6c4b8c7d28bdf782ed7c3731123ab", null ],
    [ "fill", "classMatrix.html#a1fd0e5376eb22da8167da0e0b0639bc3", null ],
    [ "getNumCols", "classMatrix.html#a436cc7ea76a0a148978240e0a837a449", null ],
    [ "getNumRows", "classMatrix.html#a232f710270c76ff1488eb0bb0bcd7d00", null ],
    [ "operator=", "classMatrix.html#a9fa0bf7331a389b849d9deae03473333", null ],
    [ "product", "classMatrix.html#a4954bb3087c3ce6a98260445cc228143", null ],
    [ "productElem", "classMatrix.html#a57668967a7c047e13931c03f5e0accc7", null ],
    [ "read", "classMatrix.html#af6a11a0aafb3474bbc74be443dacd5bc", null ],
    [ "sum", "classMatrix.html#a303efe4932f8340ed9fbedfc95c3dabd", null ],
    [ "write", "classMatrix.html#a10f7a8f85cd29c5cab354217ce61571d", null ],
    [ "numColumns", "classMatrix.html#accc8a08144e4b459941da30ba5bef6a1", null ],
    [ "numRows", "classMatrix.html#a0eb658c64c749da9cc9705dc232fcb85", null ],
    [ "values", "classMatrix.html#a04a2aafe16a0d52b1a8334165495179a", null ]
];