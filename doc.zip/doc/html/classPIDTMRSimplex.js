var classPIDTMRSimplex =
[
    [ "SC_CTOR", "classPIDTMRSimplex.html#a59bba472650c50f0ab2ea06e2df31dde", null ],
    [ "sendGainsToVoter", "classPIDTMRSimplex.html#a28d61e2afde44f6bb6183fdda6b7dace", null ],
    [ "sendOutputGain", "classPIDTMRSimplex.html#a968db23115ecf9923c64f4108998a3ee", null ],
    [ "use_voter", "classPIDTMRSimplex.html#a5dc0c41099b897b3984709f045acef93", null ]
];