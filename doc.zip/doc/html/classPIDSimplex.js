var classPIDSimplex =
[
    [ "doPID", "classPIDSimplex.html#a2ae19d9583eb17fa4cbc89300e97f686", null ],
    [ "SC_CTOR", "classPIDSimplex.html#a03e18a6286cfd22ae078e743e607914f", null ],
    [ "setCoeffs", "classPIDSimplex.html#ae45daddb057305933f7bea6de5340eb3", null ]
];